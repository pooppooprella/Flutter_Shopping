import 'package:app1_flutter/models/Product.dart';
import 'package:flutter/material.dart';

class DetailScreen extends StatelessWidget{

  final Product? product;

  const DetailScreen({Key? key, this.product}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    throw Container();
  }
}